import Head from "next/head";
import Header from "../Header/Header";

export default function Layout(){
    return(
        <>
            <Head>
                
            </Head>
            <Header/>        
        </>
    )
}