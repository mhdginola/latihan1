const dataProduct =[
    {
        id:0,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/0.gif",
        category:"CCTV"
    },
    {
        id:1,
        product_name:"Smart Indoor PTZ CAM",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/1.png",
        category:"CCTV"
    },
    {
        id:2,
        product_name:"Smart Indoor Static CAM",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/2.png",
        category:"CCTV"
    },
    {
        id:3,
        product_name:"Smart Outdoor Bullet CAM",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/3.png",
        category:"CCTV"
    },
    {
        id:4,
        product_name:"Smart Hexagonal",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "RP.",
        thumb:"./images/10.png",
        category:"Lampu"
    },
    {
        id:5,
        product_name:"Smart DownLight",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/5.png",
        category:"Lampu"
    },
    {
        id:6,
        product_name:"Smart DreamColor Strip",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/6.png",
        category:"Lampu"
    },
    {
        id:7,
        product_name:"product 1",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/7.png",
        category:"Alarm"
    },
    {
        id:8,
        product_name:"product 2",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "RP.",
        thumb:"./images/8.png",
        category:"Alarm"
    },
    {
        id:9,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/9.png",
        category:"Alarm"
    },
    {
        id:10,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/4.png",
        category:"Lampu"
    },
    {
        id:11,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/11.png",
        category:"Switch"
    },
    {
        id:12,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/12.png",
        category:"CCTV"
    },
    {
        id:13,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/13.png",
        category:"Alarm"
    },
    {
        id:14,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/14.png",
        category:"CCTV"
    },
    {
        id:15,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/15.png",
        category:"Alarm"
    },
    {
        id:16,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/16.png",
        category:"Lampu"
    },
    {
        id:17,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/17.png",
        category:"Switch"
    },
    {
        id:18,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/18.png",
        category:"Switch"
    },
    {
        id:19,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/19.png",
        category:"Switch"
    },
    {
        id:20,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/20.png",
        category:"Switch"
    },
    {
        id:21,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/21.png",
        category:"Switch"
    },
    {
        id:22,
        product_name:"product 3",
        description:"Description, test 123 dan dan",
        price: 11000,
        currency: "Rp.",
        thumb:"./images/22.png",
        category:"Switch"
    }

]

export default dataProduct;