const dataCategory=[
    {
        id:1,
        thumbCat:"./images/catt4.png",
        cat:"CCTV"        
    },
    {
        id:2,
        thumbCat:"./images/catt4.png",
        cat:"Lampu"        
    },
    {
        id:3,
        thumbCat:"./images/catt4.png",
        cat:"Alarm"        
    },
    {
        id:4,
        thumbCat:"./images/catt4.png",
        cat:"Switch"        
    }
]

export default dataCategory;